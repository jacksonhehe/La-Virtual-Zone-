// Script para limpiar localStorage
console.log('Para limpiar localStorage, abre la consola del navegador y ejecuta:');
console.log('localStorage.clear()');
console.log('');
console.log('O ejecuta estos comandos específicos:');
console.log('localStorage.removeItem("vz_comments")');
console.log('localStorage.removeItem("vz_news")');
console.log('localStorage.removeItem("vz_posts")');
console.log('localStorage.removeItem("vz_tournaments")');
console.log('');
console.log('Luego recarga la página.'); 