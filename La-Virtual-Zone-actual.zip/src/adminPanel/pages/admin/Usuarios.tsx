import React, { useMemo, useState } from "react";
import { Search, RefreshCcw, Ban, Check } from "lucide-react";
import toast from "react-hot-toast";
// FIX: ruta corregida (de ../../../store/globalStore a ../../store/globalStore)
import { useGlobalStore as useGlobalStoreHook } from "../../store/globalStore";

type User = {
  id?: string | number;
  name?: string;
  fullName?: string;
  username?: string;
  displayName?: string;
  email?: string;
  role?: string;
  isBanned?: boolean;
  createdAt?: string | number | Date;
};

const toSafeText = (v: any) => (v ?? "").toString();
const toLower = (v: any) => toSafeText(v).toLowerCase();
const asArray = <T,>(v: any): T[] => (Array.isArray(v) ? v : []);

const Usuarios: React.FC = () => {
  const store: any = typeof useGlobalStoreHook === "function" ? useGlobalStoreHook() : {};
  const usersRaw: User[] = asArray<User>(store?.users);
  const refreshUsers = store?.refreshUsers as undefined | (() => void);
  const banUser = store?.banUser as undefined | ((id: string | number) => void);
  const unbanUser = store?.unbanUser as undefined | ((id: string | number) => void);

  const [q, setQ] = useState("");
  const [role, setRole] = useState("all");
  const [onlyBanned, setOnlyBanned] = useState(false);

  const users = useMemo(() => {
    let list = [...usersRaw];
    if (q.trim()) {
      const needle = toLower(q);
      list = list.filter((u) => {
        const hay =
          toLower(u.name) +
          " " +
          toLower(u.fullName) +
          " " +
          toLower(u.username) +
          " " +
          toLower(u.displayName) +
          " " +
          toLower(u.email) +
          " " +
          toLower(u.id);
        return hay.includes(needle);
      });
    }
    if (role !== "all") {
      list = list.filter((u) => toLower(u.role) === toLower(role));
    }
    if (onlyBanned) {
      list = list.filter((u) => !!u.isBanned);
    }
    // orden simple por fecha (si existe) desc
    list.sort((a, b) => {
      const ta = new Date(a.createdAt ?? 0).getTime();
      const tb = new Date(b.createdAt ?? 0).getTime();
      return tb - ta;
    });
    return list;
  }, [usersRaw, q, role, onlyBanned]);

  const onRefresh = () => {
    if (typeof refreshUsers === "function") refreshUsers();
    else toast("No hay acción refreshUsers en el store");
  };

  const onBan = (u: User) => {
    if (!u?.id) return;
    if (u.isBanned) {
      if (typeof unbanUser === "function") unbanUser(u.id);
      else toast("No hay acción unbanUser en el store");
    } else {
      if (typeof banUser === "function") banUser(u.id);
      else toast("No hay acción banUser en el store");
    }
  };

  const roles = useMemo(() => {
    const set = new Set<string>();
    usersRaw.forEach((u) => {
      const r = toSafeText(u.role).trim();
      if (r) set.add(r);
    });
    return Array.from(set).sort();
  }, [usersRaw]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400">
            <UsersIcon />
          </div>
          <div>
            <h1 className="text-xl font-semibold text-white">Usuarios</h1>
            <p className="text-sm text-gray-400">Gestión y moderación</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn-secondary" onClick={onRefresh}>
            <RefreshCcw size={16} className="mr-2" /> Recargar
          </button>
        </div>
      </div>

      <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700/50 p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2" size={16} />
            <input
              className="input pl-9"
              placeholder="Buscar por nombre, email o id"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <div>
            <select className="input" value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="all">Todos los roles</option>
              {roles.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
          <label className="inline-flex items-center gap-2 text-sm text-gray-300">
            <input
              type="checkbox"
              className="form-checkbox"
              checked={onlyBanned}
              onChange={(e) => setOnlyBanned(e.target.checked)}
            />
            Solo bloqueados
          </label>
          <div className="text-sm text-gray-400 self-center">
            {users.length} resultado(s)
          </div>
        </div>
      </div>

      <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700/50 p-4">
        {users.length ? (
          <div className="divide-y divide-gray-800">
            {users.map((u) => (
              <div key={toSafeText(u.id)} className="py-3 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div>
                    <div className="text-sm text-white font-medium">
                      {toSafeText(u.displayName) ||
                        toSafeText(u.fullName) ||
                        toSafeText(u.name) ||
                        toSafeText(u.username) ||
                        "(sin nombre)"}
                    </div>
                    <div className="text-xs text-gray-400">
                      {toSafeText(u.email)} • ID: {toSafeText(u.id)} • Rol: {toSafeText(u.role) || "—"}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="btn-secondary" onClick={() => onBan(u)}>
                    {u.isBanned ? (
                      <>
                        <Check size={14} className="mr-2" /> Desbloquear
                      </>
                    ) : (
                      <>
                        <Ban size={14} className="mr-2" /> Bloquear
                      </>
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-sm text-gray-400">No hay usuarios para mostrar.</div>
        )}
      </div>
    </div>
  );
};

// Icono sencillo para el header (evita depender de librerías externas aquí)
const UsersIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
    <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
  </svg>
);

export default Usuarios;
