// Shim para mantener compatibilidad con imports antiguos.
// Reexporta useAuth (y AuthProvider por si lo necesitas) desde AuthContext.
export { useAuth, AuthProvider } from "./AuthContext";
