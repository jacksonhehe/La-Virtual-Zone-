export enum Role {
  ADMIN = 'admin',
  CLUB = 'club',
  USER = 'user',
}
