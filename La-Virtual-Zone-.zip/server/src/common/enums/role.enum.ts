export enum Role {
  ADMIN = 'ADMIN',
  CLUB = 'CLUB',
  USER = 'USER',
}
