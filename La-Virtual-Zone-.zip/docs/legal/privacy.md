# Pol\xC3\xADtica de Privacidad

Explicamos qu\xC3\xA9 datos recopilamos y c\xC3\xB3mo los utilizamos para ofrecer nuestros servicios.
