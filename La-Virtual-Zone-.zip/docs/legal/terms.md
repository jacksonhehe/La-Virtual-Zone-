# T\xC3\xA9rminos y Condiciones

Este documento establece las condiciones de uso de La Virtual Zone. Al utilizar la plataforma aceptas cumplir con estas reglas.
