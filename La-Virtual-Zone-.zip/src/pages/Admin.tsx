import '../adminPanel/index.css';
import React from 'react';
import AdminApp from '../adminPanel/App';

export default function Admin() {
  return <AdminApp />;
}
