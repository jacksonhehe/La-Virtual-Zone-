import PrivacyContent from '../../docs/legal/privacy.md';

const Privacy = () => (
  <div className="prose prose-invert max-w-3xl mx-auto p-4">
    <PrivacyContent />
  </div>
);

export default Privacy;
