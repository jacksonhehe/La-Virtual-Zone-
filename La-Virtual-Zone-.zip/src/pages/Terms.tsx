import TermsContent from '../../docs/legal/terms.md';

const Terms = () => (
  <div className="prose prose-invert max-w-3xl mx-auto p-4">
    <TermsContent />
  </div>
);

export default Terms;
