import EconomyAdminPanel from '../../components/admin/EconomyAdminPanel';

const Economy = () => {
  return (
    <div className="p-6">
      <EconomyAdminPanel />
    </div>
  );
};

export default Economy; 