import  CalendarAdminPanel from '../../components/admin/CalendarAdminPanel';

const Calendario = () => {
  return (
    <div className="p-6">
      <CalendarAdminPanel /> 
    </div>
  );
};

export default Calendario;
 
 