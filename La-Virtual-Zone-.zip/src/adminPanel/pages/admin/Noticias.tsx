import  NewsAdminPanel from '../../components/admin/NewsAdminPanel';

const Noticias = () => {
  return (
    <div className="p-6">
      <NewsAdminPanel />
    </div>
  );
};

export default Noticias;
 