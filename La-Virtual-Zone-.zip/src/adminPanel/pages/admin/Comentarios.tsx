import  CommentsAdminPanel from '../../components/admin/CommentsAdminPanel';

const Comentarios = () => {
  return (
    <div className="p-6">
      <CommentsAdminPanel /> 
    </div>
  );
};

export default Comentarios; 
 