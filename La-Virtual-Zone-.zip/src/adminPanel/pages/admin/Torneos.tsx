import  TournamentsAdminPanel from '../../components/admin/TournamentsAdminPanel';

const Torneos = () => {
  return (
    <div className="p-6">
      <TournamentsAdminPanel />
    </div>
  );
};

export default Torneos;
 