import  ActivityAdminPanel from '../../components/admin/ActivityAdminPanel';

const Actividad = () => {
  return (
    <div className="p-6">
      <ActivityAdminPanel /> 
    </div>
  );
};

export default Actividad;
 