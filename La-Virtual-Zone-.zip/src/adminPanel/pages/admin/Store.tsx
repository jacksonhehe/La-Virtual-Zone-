import StoreAdminPanel from '../../components/admin/StoreAdminPanel';

const Store = () => {
  return (
    <div className="p-6">
      <StoreAdminPanel />
    </div>
  );
};

export default Store; 