declare module 'html2canvas';
